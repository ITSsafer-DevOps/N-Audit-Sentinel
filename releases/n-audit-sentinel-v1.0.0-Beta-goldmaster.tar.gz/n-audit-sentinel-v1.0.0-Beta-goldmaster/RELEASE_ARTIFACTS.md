# Release Artifacts - v1.0.0-Beta

Artifacts created during Phase 4 (fresh build):

- n-audit-sentinel-beta-bin.tar.gz
- n-audit-sentinel-beta-bin.tar.gz.sha256
- backups/n-audit-sentinel-beta-source-code-goldmaster.tar.gz

Checksums recorded in backups/BACKUP_LOG.txt

