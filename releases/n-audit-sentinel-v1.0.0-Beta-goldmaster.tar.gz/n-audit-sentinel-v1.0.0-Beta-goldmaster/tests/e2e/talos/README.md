# Talos E2E tests

Talos requires an external cluster. This directory contains harnesses and manifests that can be used against a Talos-managed Kubernetes cluster.

If no Talos cluster is present, tests should be marked as skipped in CI.
