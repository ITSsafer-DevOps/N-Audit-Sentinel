release-manager CLI (scaffold)
- Purpose: deterministic builds, tagging, artifact signing, checksum generation, and upload.
- Next: implement subcommands and unit tests under internal/releasemgr.
