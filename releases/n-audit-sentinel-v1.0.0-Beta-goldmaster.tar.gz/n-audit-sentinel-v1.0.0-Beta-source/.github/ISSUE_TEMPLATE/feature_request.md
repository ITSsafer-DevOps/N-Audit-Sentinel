---
name: Feature request
about: Suggest an idea for this project
---

**Describe the feature**
A clear description of the feature you'd like to see.

**Use case**
Explain why this feature is useful.

**Implementation thoughts**
Optional notes on how this could be implemented.
