backup-manager CLI (scaffold)
- Purpose: deterministic source archival, optional encryption, checksum generation and upload to secure storage.
- Next: implement functions and unit tests under internal/backupmgr.
