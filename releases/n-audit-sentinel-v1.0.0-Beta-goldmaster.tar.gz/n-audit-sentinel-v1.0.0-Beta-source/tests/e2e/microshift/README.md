# MicroShift E2E tests

This directory contains test harness descriptions for MicroShift. Tests should detect environment and skip if prerequisites are missing.
