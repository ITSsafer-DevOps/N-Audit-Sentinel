# OpenShift E2E tests

OpenShift requires specific permissions and may require `oc` cli. Tests should be skipped if prerequisites are not present.

This directory should contain OpenShift-specific manifests and harness scripts.